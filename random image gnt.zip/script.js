const currentImageElement = document.querySelector(".container .img-boxes")

const imagesArray = [];
let currentImageIndex = 0;

for (let i = 0; i < 12; i++) {
    const imageElement = document.createElement("img");
    imageElement.alt = "photo";
    imageElement.src = `https://source.unsplash.com/random/300x300?sig=${i}`;
  
    imagesArray.push(imageElement);

    if (i == currentImageIndex) {
        currentImageElement.appendChild(imageElement)
        currentImageIndex++
    }
}